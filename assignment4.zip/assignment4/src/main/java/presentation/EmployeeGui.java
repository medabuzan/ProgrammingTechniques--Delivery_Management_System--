package presentation;

import javax.swing.*;
import java.awt.*;
import java.util.Observable;
import java.util.Observer;

/**
 * Class that implement the employee window
 */
public class EmployeeGui extends JFrame implements Observer {

    private JPanel mainPanel;

    private JTextArea orderDetails;
    private JButton takeOrder;

    /**
     * Constructs the employee window object, creating and adding all the components
     */
    public EmployeeGui() {

        super("Employee Window");

        this.setSize(450, 400);

        mainPanel = new JPanel(new FlowLayout());
        orderDetails = new JTextArea(20, 40);
        orderDetails.setFont(new Font("Calibri", Font.BOLD, 12));
        takeOrder = new JButton("Finish Order");

        mainPanel.add(orderDetails);
        mainPanel.add(takeOrder);
        addActionListener();

        this.getContentPane().add(mainPanel);
        this.setVisible(false);
    }

    /**
     * Displays the details of an ordered, at the time it is placed by a client
     * @param o not used but required by overriding
     * @param arg not used but required by overriding
     */
    @Override
    public void update(Observable o, Object arg) {
        if(arg == null)
            return;
        String message = (String) arg;
        orderDetails.setText(message);
    }

    /**
     * Creates action listener for the takeOrder button
     * which will just flush the contents of the text area
     */
    public void addActionListener() {
        this.takeOrder.addActionListener(e -> {
            orderDetails.setText("");
        });
    }
}
