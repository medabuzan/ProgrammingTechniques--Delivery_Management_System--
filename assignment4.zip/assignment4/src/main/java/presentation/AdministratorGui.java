package presentation;

import bussiness.DeliveryService;
import composition.MenuItem;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Class that implements the Administration window
 */
public class AdministratorGui extends JFrame {

    private DeliveryService deliveryService;

    private JPanel mainPanel;
    private JPanel administrationPanel;
    private JPanel reportsPanel;

    private JScrollPane tablePanel;
    private JTable menuTable;

    private JButton uploadButton;
    private JButton addButton;
    private JButton updateButton;
    private JButton deleteButton;

    private JRadioButton baseItemButton;
    private JRadioButton compositeItemButton;
    private ButtonGroup radioGroup;

    private JLabel nameLabel;
    private JLabel ratingLabel;
    private JLabel caloriesLabel;
    private JLabel proteinsLabel;
    private JLabel fatsLabel;
    private JLabel sodiumLabel;
    private JLabel priceLabel;
    private JLabel baseProductsLabel;

    private JTextField nameText;
    private JTextField ratingText;
    private JTextField caloriesText;
    private JTextField proteinsText;
    private JTextField fatsText;
    private JTextField sodiumText;
    private JTextField priceText;
    private JTextField baseProductsText;

    private JTextField inputText;
    private JComboBox<String> options;
    private JButton generateButton;
    private JScrollPane scrollPanel;
    private JTextArea reportsArea;

    /**
     * Constructor that creates and adds all the necessary components for the Administration Window
     * @param deliveryService the unique deliveryService object used to perform operations on menu items and orders
     */
    public AdministratorGui(DeliveryService deliveryService) {

        super("Administration window");

        this.deliveryService = deliveryService;

        createPanels();
        createButtons();
        createLabels();
        createTextFields();
        createTable(deliveryService.getMenu());
        createReportComponents();
        addActionListeners();
        addAdministrationComponents();
        addReportsComponents();
        addGenerateActionListener();

        this.mainPanel.add(administrationPanel);
        this.mainPanel.add(reportsPanel);

        this.setSize(new Dimension(1000, 800));
        this.getContentPane().add(mainPanel);
        this.setVisible(false);
    }

    /**
     * Creates the panels of the window
     */
    public void createPanels() {
        this.mainPanel = new JPanel(new GridLayout(1, 2));
        this.administrationPanel = new JPanel(new FlowLayout());
        this.reportsPanel = new JPanel(new FlowLayout());
    }

    /**
     * Creates the labels of the window
     */
    public void createLabels() {
        nameLabel = new JLabel("Name:");
        nameLabel.setFont(new Font("Calibri", Font.BOLD, 12));

        ratingLabel = new JLabel("Rating:");
        ratingLabel.setFont(new Font("Calibri", Font.BOLD, 12));

        caloriesLabel = new JLabel("Calories:");
        caloriesLabel.setFont(new Font("Calibri", Font.BOLD, 12));

        proteinsLabel = new JLabel("Proteins:");
        proteinsLabel.setFont(new Font("Calibri", Font.BOLD, 12));

        fatsLabel = new JLabel("Fats:");
        fatsLabel.setFont(new Font("Calibri", Font.BOLD, 12));

        sodiumLabel = new JLabel("Sodium:");
        sodiumLabel.setFont(new Font("Calibri", Font.BOLD, 12));

        priceLabel = new JLabel("Price:");
        priceLabel.setFont(new Font("Calibri", Font.BOLD, 12));

        baseProductsLabel = new JLabel("Base Products:");
        baseProductsLabel.setFont(new Font("Calibri", Font.BOLD, 12));
    }

    /**
     * creates the text fields of the window
     */
    public void createTextFields() {
        nameText = new JTextField(42);
        nameText.setFont(new Font("Calibri", Font.BOLD, 12));

        ratingText = new JTextField(40);
        ratingText.setFont(new Font("Calibri", Font.BOLD, 12));

        caloriesText = new JTextField(40);
        caloriesText.setFont(new Font("Calibri", Font.BOLD, 12));

        proteinsText  = new JTextField(42);
        proteinsText .setFont(new Font("Calibri", Font.BOLD, 12));

        fatsText = new JTextField(42);
        fatsText .setFont(new Font("Calibri", Font.BOLD, 12));

        sodiumText  = new JTextField(42);
        sodiumText .setFont(new Font("Calibri", Font.BOLD, 12));

        priceText  = new JTextField(40);
        priceText.setFont(new Font("Calibri", Font.BOLD, 12));

        baseProductsText  = new JTextField(38);
        baseProductsLabel.setFont(new Font("Calibri", Font.BOLD, 12));
    }

    /**
     * creates the buttons of the window
     */
    public void createButtons() {
        baseItemButton = new JRadioButton("Base product");
        compositeItemButton = new JRadioButton("Composite product");

        radioGroup = new ButtonGroup();
        radioGroup.add(baseItemButton);
        radioGroup.add(compositeItemButton);

        uploadButton = new JButton("Upload Menu from csv");
        addButton = new JButton("Add");
        updateButton = new JButton("Update");
        deleteButton = new JButton("Delete");
    }

    /**
     * Creates the table in which the items from the menu will be displayed
     * @param items list of MenuItems representing the menu
     */
    public void createTable(List<MenuItem> items) {
        String[] columns = {"title", "rating", "calories", "proteins", "fats", "sodium", "price"};
        List<String[]> attributeList = new ArrayList<>();

        for(MenuItem item: items) {
            String[] attributes = {item.getTitle(), item.getRating().toString(), item.getCalories().toString(),
                    item.getProteins().toString(), item.getFats().toString(), item.getSodium().toString(),
                    item.getPrice().toString()};
            attributeList.add(attributes);
        }

        menuTable = new JTable(attributeList.toArray(new String[0][0]), columns);

        tablePanel = new JScrollPane(menuTable);
    }

    /**
     * Creates action listeners for the buttons with their respective behavior
     */
    public void addActionListeners() {
        uploadButton.addActionListener(action -> {
            deliveryService.uploadMenu();
            updateTable();
        });
        deleteButton.addActionListener(action ->  {
            deliveryService.deleteProduct(nameText.getText());
            updateTable();
        });

        addButton.addActionListener(action -> {
            String itemType = getSelectedButton();

            if(itemType.equals("base")) {
                deliveryService.addBaseProduct(nameText.getText(), ratingText.getText(), caloriesText.getText(),
                        proteinsText.getText(), fatsText.getText(), sodiumText.getText(), priceText.getText());
            } else {
                deliveryService.addCompositeProduct(nameText.getText(), baseProductsText.getText());
            }
            updateTable();
        });

        updateButton.addActionListener(action -> {
            String itemType = getSelectedButton();

            if(itemType.equals("base")) {
                deliveryService.updateBaseProduct(nameText.getText(), ratingText.getText(), caloriesText.getText(),
                        proteinsText.getText(), fatsText.getText(), sodiumText.getText(), priceText.getText());
            } else {
                deliveryService.updateCompositeProduct(nameText.getText(), baseProductsText.getText());
            }

            updateTable();
        });
    }

    /**
     * Returns a string which represent the name of the radio button selected
     * @return a string ("base" or "composite")
     */
    public String getSelectedButton() {

        if(compositeItemButton.isSelected())
            return "composite";
        return "base";
    }

    /**
     * Updates the contents of the table based on the contents of the updated menu list
     */
    public void updateTable() {
        administrationPanel.remove(tablePanel);
        createTable(deliveryService.getMenu());
        administrationPanel.add(tablePanel);
        mainPanel.updateUI();
    }

    /**
     * Creates the ui components present in the reports panel
     */
    public void createReportComponents() {
        inputText  = new JTextField(42);
        inputText .setFont(new Font("Calibri", Font.BOLD, 12));

        String[] attributes = {"time interval", "products times", "clients", "products day"};
        options = new JComboBox<>(attributes);
        options.setSelectedIndex(0);

        generateButton = new JButton("Generate Report");

        reportsArea = new JTextArea(35, 40);
        scrollPanel = new JScrollPane(reportsArea);
    }

    /**
     * Adds all the report ui components to the reports panel
     */
    public void addReportsComponents() {
        reportsPanel.add(inputText);
        reportsPanel.add(options);
        reportsPanel.add(generateButton);
        reportsPanel.add(scrollPanel);
    }

    /**
     * Adds an action listener of the generate report button
     */
    public void addGenerateActionListener() {
        generateButton.addActionListener(action -> {
            String reportText = deliveryService.generateReport((String) options.getSelectedItem(), inputText.getText());
            reportsArea.setText(reportText);
        });
    }

    /**
     * Adds all the administration components to the administration panel
     */
    public void addAdministrationComponents() {

        administrationPanel.add(nameLabel);
        administrationPanel.add(nameText);
        administrationPanel.add(ratingLabel);
        administrationPanel.add(ratingText);
        administrationPanel.add(caloriesLabel);
        administrationPanel.add(caloriesText);
        administrationPanel.add(proteinsLabel);
        administrationPanel.add(proteinsText);
        administrationPanel.add(fatsLabel);
        administrationPanel.add(fatsText);
        administrationPanel.add(sodiumLabel);
        administrationPanel.add(sodiumText);
        administrationPanel.add(priceLabel);
        administrationPanel.add(priceText);
        administrationPanel.add(baseProductsLabel);
        administrationPanel.add(baseProductsText);

        administrationPanel.add(baseItemButton);
        administrationPanel.add(compositeItemButton);
        administrationPanel.add(uploadButton);
        administrationPanel.add(addButton);
        administrationPanel.add(deleteButton);
        administrationPanel.add(updateButton);

        administrationPanel.add(tablePanel);
    }
}
