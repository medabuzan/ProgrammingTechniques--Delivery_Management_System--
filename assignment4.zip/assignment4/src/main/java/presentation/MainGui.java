package presentation;

import bussiness.AuthenticationService;
import bussiness.DeliveryService;

import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

/**
 * Class that implement the main window - the login/register window
 */
public class MainGui extends JFrame {

    private AdministratorGui administratorGui;
    private ClientGui clientGui;
    private EmployeeGui employeeGui;

    private AuthenticationService authenticator;
    private DeliveryService deliveryService;

    private JPanel mainPanel;

    private JLabel userLabel;
    private JLabel passwordLabel;
    private JTextField userText;
    private JPasswordField passwordText;

    private JRadioButton adminButton;
    private JRadioButton clientButton;
    private JRadioButton employeeButton;

    private ButtonGroup radioGroup;

    private JButton registerButton;
    private JButton loginButton;

    /**
     * Construct the main window and creates and adds to it all the necessary components
     */
    public MainGui() {

        super("Food Delivery Management System");

        deliveryService = new DeliveryService();
        authenticator = new AuthenticationService();

        administratorGui = new AdministratorGui(deliveryService);
        clientGui = new ClientGui(deliveryService, authenticator);
        employeeGui = new EmployeeGui();
        deliveryService.addObserver(employeeGui);
        deliveryService.addObserver(clientGui);

        addListener();
        this.setSize(500,200);
        this.mainPanel = new JPanel(new FlowLayout());

        createLabelsAndTextFields();
        createButtons();

        addRegisterListeners();
        addLoginListener();
        addComponents();

        this.getContentPane().add(mainPanel);
        this.setVisible(true);
    }

    /**
     * Creates the labels and text fields of the window
     */
    public void createLabelsAndTextFields() {
        userLabel = new JLabel("Username:");
        userLabel.setFont(new Font("Calibri", Font.BOLD, 16));

        passwordLabel = new JLabel("Password:");
        passwordLabel.setFont(new Font("Calibri", Font.BOLD, 16));

        userText = new JTextField(30);
        userText.setFont(new Font("Calibri", Font.BOLD, 16));

        passwordText = new JPasswordField(30);
        passwordText.setEchoChar('*');
        passwordText.setFont(new Font("Calibri", Font.BOLD, 16));
    }

    /**
     * Creates the buttons of the window
     */
    public void createButtons() {

        adminButton = new JRadioButton("Admin");
        clientButton = new JRadioButton("Client");
        employeeButton = new JRadioButton("Employee");

        radioGroup = new ButtonGroup();
        radioGroup.add(adminButton);
        radioGroup.add(clientButton);
        radioGroup.add(employeeButton);

        loginButton = new JButton("Login");
        registerButton = new JButton("Register");
    }

    /**
     * Adds the listener for the register button
     */
    public void addRegisterListeners() {
        registerButton.addActionListener(e -> {

            String rank = getRank();

            if (rank != null) {
                authenticator.createAccount(userText.getText(), passwordText.getText(), rank);
                loginButton.doClick();
            }
        });
    }

    /**
     * Adds the listener for the login button
     */
    public void addLoginListener() {
        loginButton.addActionListener(e -> {

            String rank = getRank();
            if(rank != null && authenticator.isAccount(userText.getText(), passwordText.getText(), rank)) {
                switch (rank) {
                    case "admin":
                        administratorGui.setVisible(true);
                        break;
                    case "client":
                        clientGui.setUsername(userText.getText());
                        clientGui.setVisible(true);
                        break;
                    case "employee":
                        employeeGui.setVisible(true);
                        break;
                    default:
                        break;
                }
            } else if(rank == null) {
                JOptionPane.showMessageDialog(this, "Please select your role!");
            } else {
                JOptionPane.showMessageDialog(this, "Invalid authentication!");
            }

            userText.setText("");
            passwordText.setText("");
        });
    }

    /**
     * Returns a string representing the type of user that tries to login or to register
     * @return a string ("admin", "client" or "employee")
     */
    public String getRank() {

        if(adminButton.isSelected())
            return "admin";
        if(clientButton.isSelected())
            return "client";
        if(employeeButton.isSelected())
            return "employee";

        return null;
    }

    /**
     * Adds all the components to the mainPanel of the window
     */
    public void addComponents() {
        this.mainPanel.add(userLabel);
        this.mainPanel.add(userText);

        this.mainPanel.add(passwordLabel);
        this.mainPanel.add(passwordText);

        this.mainPanel.add(adminButton);
        this.mainPanel.add(clientButton);
        this.mainPanel.add(employeeButton);

        this.mainPanel.add(loginButton);
        this.mainPanel.add(registerButton);
    }

    /**
     * Creates a window listener that will serialize all the crucial information stored in authentication and delivery
     * objects when the window is closing
     */
    public void addListener() {
        this.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                authenticator.serializeAccounts();
                deliveryService.serializeObjects();
                System.exit(0);
            }
        });
    }
}
