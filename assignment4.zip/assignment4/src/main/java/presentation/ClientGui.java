package presentation;

import bussiness.AuthenticationService;
import bussiness.DeliveryService;
import composition.MenuItem;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Observable;
import java.util.Observer;

import static javax.swing.JOptionPane.INFORMATION_MESSAGE;

/**
 * Class that implements the Client window
 */
public class ClientGui extends JFrame implements Observer {

    private DeliveryService deliveryService;
    private AuthenticationService authenticationService;
    private String username;

    private JPanel mainPanel;
    private JPanel optionsPanel;
    private JScrollPane tablePanel;

    private JTextField orderText;
    private JTextField searchText;

    private JButton placeOrderButton;
    private JButton searchButton;

    private JComboBox<String> filterBox;

    private JTable menuTable;

    /**
     * Constructs the client window object and instantiates and adds all the necessary components
     * @param deliveryService the unique deliveryService object used to perform operations on menu items and orders
     * @param authenticationService object that is used for receiving information about the account used by the client
     */
    public ClientGui(DeliveryService deliveryService, AuthenticationService authenticationService) {

        super("Client Window");

        this.deliveryService = deliveryService;
        this.authenticationService = authenticationService;
        createAndAddPanels();
        createButtons();
        addActionListeners();
        createTable(deliveryService.getMenu());
        createComboBox();
        createTextFields();
        addComponents();

        this.setSize(new Dimension(1200, 800));
        this.getContentPane().add(mainPanel);
        this.setVisible(false);
    }

    /**
     * Creates and adds the panels contained in the window
     */
    public void createAndAddPanels() {
        mainPanel = new JPanel(new GridLayout(1, 2));
        optionsPanel = new JPanel(new FlowLayout());

        mainPanel.add(optionsPanel);
    }

    /**
     * Creates the buttons used by the window
     */
    public void createButtons() {
        placeOrderButton = new JButton("Place Order");
        searchButton = new JButton("Search");
    }

    /**
     * Creates the text fields used by the window
     */
    public void createTextFields() {

        orderText = new JTextField(30);
        orderText.setFont(new Font("Calibri", Font.BOLD, 14));
        orderText.setText("");

        searchText = new JTextField(30);
        searchText.setFont(new Font("Calibri", Font.BOLD, 14));
        searchText.setText("");
    }

    /**
     * Creates the combo box used by the window
     */
    public void createComboBox() {
        String[] attributes = {"keyword", "rating", "calories", "proteins", "fats", "sodium", "price"};
        filterBox = new JComboBox<>(attributes);
        filterBox.setSelectedIndex(0);
    }

    /**
     * Creates the table used by the window that contains all the items present in the menu
     */
    public void createTable(List<MenuItem> items) {
        String[] columns = {"title", "rating", "calories", "proteins", "fats", "sodium", "price"};
        List<String[]> attributeList = new ArrayList<>();

        for(MenuItem item: items) {
            String[] attributes = {item.getTitle(), item.getRating().toString(), item.getCalories().toString(),
                    item.getProteins().toString(), item.getFats().toString(), item.getSodium().toString(),
                    item.getPrice().toString()};
            attributeList.add(attributes);
        }

        menuTable = new JTable(attributeList.toArray(new String[0][0]), columns);

        tablePanel = new JScrollPane(menuTable);
        mainPanel.add(tablePanel);
    }

    /**
     * Adds action listeners for the buttons used in the window
     */
    public void addActionListeners() {
        searchButton.addActionListener(action -> {
            String filter = String.valueOf(filterBox.getSelectedItem());

            mainPanel.remove(tablePanel);
            if(searchText.getText().equals("")) {
                createTable(deliveryService.getMenu());
            } else {
                List<MenuItem> menuItemList = deliveryService.searchProduct(filter, searchText.getText());
                createTable(menuItemList);
            }
            mainPanel.updateUI();
        });

        placeOrderButton.addActionListener(action -> {
            deliveryService.createOrder(orderText.getText(), this.username, this.authenticationService);
            JOptionPane.showMessageDialog(this, "Order successfully placed!", "Order",
                    INFORMATION_MESSAGE);
        });
    }

    /**
     * Adds the components to the panel
     */
    public void addComponents() {
        optionsPanel.add(orderText);
        optionsPanel.add(placeOrderButton);
        optionsPanel.add(searchText);
        optionsPanel.add(searchButton);
        optionsPanel.add(filterBox);
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    /**
     * Updates the contents of the table when a change occurs in the menu item list in delivery service
     * @param o not used but required by overriding
     * @param arg not used but required by overriding
     */
    @Override
    public void update(Observable o, Object arg) {
        mainPanel.remove(tablePanel);
        createTable(deliveryService.getMenu());
        mainPanel.updateUI();
    }
}
