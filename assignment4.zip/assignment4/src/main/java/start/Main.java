package start;

import presentation.MainGui;

/**
 * The class that is running this applicati
 */
public class Main {

    /**
     * The main method of the application which starts it by creating a new MainGui object
     * @param argv the default required parameter of the main function
     */
    public static void main(String argv[]) {
        MainGui mainGui = new MainGui();
    }
}
