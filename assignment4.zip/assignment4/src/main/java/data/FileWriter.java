package data;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

public class FileWriter {

    /**
     * Creates a new file called bill_no_(number).txt in the bills directory and writes the given message to it
     * @param message a string containing all the information in the bill generated for a specific order
     */
    public void createBill(String message) {

        File directory = new File("bills\\");
        int fileCount = directory.list().length;

        String fileName = "bills\\bill_no_" + (fileCount + 1) + ".txt";
        File billFile = new File(fileName);

        try {
            billFile.createNewFile();
            java.io.FileWriter writer = new java.io.FileWriter(fileName);
            writer.write(message);
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Reads from order_id.txt file the next unique identifier of an order
     * @return an integer representing the next order id that will be used to register a new order
     */
    public Integer readOrderId() {
        try {
            File file = new File("data\\order_id.txt");
            Scanner myReader = new Scanner(file);
            String data = myReader.nextLine();
            myReader.close();
            return Integer.parseInt(data);
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }

        return null;
    }

    /**
     * Writes to order_id.txt file the next unique identifier of an order
     * @param orderId an integer representing the next order id that will be used to register a new order
     */
    public void writeOrderId(Integer orderId) {
        try {
            File file = new File("data\\order_id.txt");
            java.io.FileWriter writer = new java.io.FileWriter(file);
            writer.write(orderId.toString());
            writer.close();
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
