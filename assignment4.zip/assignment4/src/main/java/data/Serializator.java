package data;

import bussiness.Account;
import bussiness.Order;
import composition.MenuItem;

import java.io.*;
import java.util.List;
import java.util.Map;

/**
 * The class that handles all the serilaizations and deserializations of objects in this application
 */
public class Serializator {

    /**
     * Serializes to menu.ser the list provided as parameter
     * @param menuItems a list of MenuItems
     */
    public void serializeMenuItems(List<MenuItem> menuItems) {

        try {
            FileOutputStream menuFile = new FileOutputStream("data\\menu.ser");
            ObjectOutputStream output = new ObjectOutputStream(menuFile);

            output.writeObject(menuItems);

            output.close();
            menuFile.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Deserializes and returns a list of MenuItems from menu.ser
     * @return the new generated list of MenuItems
     */
    public List<MenuItem> deserializeMenuItems() {

        try {
            FileInputStream menuFile = new FileInputStream("data\\menu.ser");
            ObjectInputStream input = new ObjectInputStream(menuFile);

            List<MenuItem> menuItems;

            menuItems = (List<MenuItem>) input.readObject();

            input.close();
            menuFile.close();

            return menuItems;

        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            System.out.println("Here is the problem?");
        }

        return null;
    }

    /**
     * Serializes to accounts.ser the list provided as parameter
     * @param accounts a list of Accounts
     */
    public void serializeAccounts(List<Account> accounts) {

        try {
            FileOutputStream menuFile = new FileOutputStream("data\\accounts.ser");
            ObjectOutputStream output = new ObjectOutputStream(menuFile);

            output.writeObject(accounts);

            output.close();
            menuFile.close();

        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    /**
     * Deserializes and returns a list of Accounts from accounts.ser
     * @return the new generated list of Accounts
     */
    public List<Account> deserializeAccounts() {

        try {
            FileInputStream menuFile = new FileInputStream("data\\accounts.ser");
            ObjectInputStream input = new ObjectInputStream(menuFile);

            List<Account> accounts;

            accounts = (List<Account>) input.readObject();

            input.close();
            menuFile.close();

            return accounts;

        } catch (EOFException e) {
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            System.out.println("Here is the problem?");
        }

        return null;
    }

    /**
     * Serializes to orders.ser the list provided as parameter
     * @param orders a list of Orders
     */
    public void serializeOrders(List<Order> orders) {

        try {
            FileOutputStream menuFile = new FileOutputStream("data\\orders.ser");
            ObjectOutputStream output = new ObjectOutputStream(menuFile);
            output.writeObject(orders);
            output.close();
            menuFile.close();

        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    /**
     * Deserializes and returns a list of Orders from orders.ser
     * @return the new generated list of Orders
     */
    public List<Order> deserializeOrders() {

        try {
            FileInputStream menuFile = new FileInputStream("data\\orders.ser");
            ObjectInputStream input = new ObjectInputStream(menuFile);
            List<Order> orders = (List<Order>) input.readObject();
            input.close();
            menuFile.close();
            return orders;

        } catch (EOFException e) {
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            System.out.println("Here is the problem?");
        }

        return null;
    }

    /**
     * Serializes to order_information.ser the map provided as parameter
     * @param map a mapping between orders and all the products that compose that order
     */
    public void serializeOrderInformation(Map<Order, List<MenuItem>> map) {

        try {
            FileOutputStream menuFile = new FileOutputStream("data\\order_information.ser");
            ObjectOutputStream output = new ObjectOutputStream(menuFile);
            output.writeObject(map);
            output.close();
            menuFile.close();

        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    /**
     * Deserializes and returns a map of Order information from order_information.ser
     * @return the new generated map of Order information
     */
    public Map<Order, List<MenuItem>> deserializeOrderInformation() {

        try {
            FileInputStream menuFile = new FileInputStream("data\\order_information.ser");
            ObjectInputStream input = new ObjectInputStream(menuFile);
            Map<Order, List<MenuItem>> orders = (Map<Order, List<MenuItem>>) input.readObject();
            input.close();
            menuFile.close();
            return orders;

        } catch (EOFException e) {
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            System.out.println("Here is the problem?");
        }
        return null;
    }
}
