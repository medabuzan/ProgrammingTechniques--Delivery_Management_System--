package bussiness;

import java.util.List;
import composition.MenuItem;

public interface IDeliveryServiceProcessing {

    /**
     * @pre products.csv exists
     * @post menu (List<MenuItem>) not empty
     */
    void uploadMenu();

    /**
     * @pre item with title name should be in the menu list
     * @post item with title name should not be in the menu list
     */
    void deleteProduct(String name);

    /**
     * @pre item with title name should not be in the menu list
     * @post item with title name should be in the menu list
     */
    void addBaseProduct(String name, String rating, String calories, String proteins, String fats, String sodium,
                        String price);

    /**
     * @pre item with title name should not be in the menu list
     * @post item with title name should be in the menu list
     */
    void addCompositeProduct(String name, String titlesString);

    /**
     * @pre item with title name should be in the menu list
     * @post item with title name should have its attributes equal with those provided
     */
    void updateBaseProduct(String name, String rating, String calories, String proteins, String fats, String sodium,
                           String price);

    /**
     * @pre item with title name should be in the menu list
     * @post item with title name should contain the products specified in the titlesString
     */
    void updateCompositeProduct(String title, String titlesString);

    /**
     * @pre parameters should not be empty
     * @post return string should not be null
     */
    String generateReport(String option, String parameters);

    /**
     * @pre provided items should exist in the menu and user should exist in the records
     * @post there exists and order with the specified products and the current order id - 1
     */
    void createOrder(String text, String user, AuthenticationService service);

    /**
     * @pre menu list should not be null
     * @post the return list should not be null, but can be empty
     */
    List<MenuItem> searchProduct(String filter, String word);
}
