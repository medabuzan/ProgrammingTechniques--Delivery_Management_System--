package bussiness;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalTime;

/**
 * Class representing the model of an order object abstraction
 */
public class Order implements Serializable {

    private Integer orderID;
    private String clientUsername;
    private LocalDate orderDate;
    private LocalTime orderTime;

    /**
     * Constructor of Order class initializes all the order's fields
     * @param id an integer representing the unique id of the order
     * @param username the username of the client that requested the order
     */
    public Order(Integer id, String username) {
        this.orderID = id;
        this.clientUsername = username;
        this.orderDate = LocalDate.now();
        this.orderTime = LocalTime.now();
    }

    /**
     * Overrides equals such that two orders are equal if they have the same unique id
     * @param o other Order object
     * @return true if ids are the same, false otherwise
     */
    @Override
    public boolean equals(Object o) {
        return ((Order) o).getOrderID().equals(this.getOrderID());
    }

    /**
     * Computes the hashCode of the order which will be the order's id
     * @return the hashcode represented by the id of the order
     */
    @Override
    public int hashCode() {
        return this.getOrderID();
    }

    /**
     * Constructs and returns as a string, this object's state
     * @return string containing the state of the object
     */
    @Override
    public String toString() {
        return "ID: " + this.getOrderID() + " Client: " + this.getClientUsername() + "\n" +
                "Date: " + this.getOrderDate() + " Time: " + this.getOrderTime() + "\n";
    }

    public Integer getOrderID() {
        return orderID;
    }

    public void setOrderID(Integer orderID) {
        this.orderID = orderID;
    }

    public String getClientUsername() {
        return clientUsername;
    }

    public LocalDate getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(LocalDate orderDate) {
        this.orderDate = orderDate;
    }

    public LocalTime getOrderTime() {
        return orderTime;
    }

    public void setOrderTime(LocalTime orderTime) {
        this.orderTime = orderTime;
    }
}
