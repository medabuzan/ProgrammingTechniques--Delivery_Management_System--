package bussiness;

import composition.BaseProduct;
import composition.CompositeProduct;
import data.FileWriter;
import data.Serializator;
import composition.MenuItem;

import java.io.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Class that implements all the operations performed on orders and menu items.
 */
public class DeliveryService extends Observable implements IDeliveryServiceProcessing {

    /**
     * @invariant orderId >= 0
     */

    private Map<Order, List<MenuItem>> orderInformation;
    private List<MenuItem> menu;
    private final Serializator serializator;
    private List<Order> orders;
    private Integer orderId;
    private final FileWriter fileWriter;

    /**
     * Instantiates needed objects, deserializes list or creates them if the deserialization can't provide any data
     */
    public DeliveryService() {

        fileWriter = new FileWriter();
        serializator = new Serializator();

        orderId = fileWriter.readOrderId();
        menu = serializator.deserializeMenuItems();
        orders = serializator.deserializeOrders();
        orderInformation = serializator.deserializeOrderInformation();

        denullify();
    }

    /**
     * Creates the lists if the deserialization failed
     */
    public void denullify() {
        if(menu == null)
            menu = new ArrayList<>();
        if(orders == null)
            orders = new ArrayList<>();
        if(orderInformation == null)
            orderInformation = new HashMap<>();
    }

    /**
     * Checks if the user and items requested are valid, then creates a new order, saves it, creates a new bill and
     * notifies the employee that it should take the command
     *
     * @param text a string containing a list of menu item names separated by a single comma
     * @param user a string containing the username of the client that performs the order
     * @param service the AuthenticationService which will provide a list of registered accounts
     */
    public void createOrder(String text, String user, AuthenticationService service) {
        assert service.getAccounts().stream().map(Account::getUsername).anyMatch(user::equals): "This user does not exist";
        List<String> productNames = Arrays.asList(text.split(","));
        productNames.forEach(product -> {
            assert menu.stream().map(MenuItem::getTitle).anyMatch(product::equals) : product + "not in the menu list";
        });
        List<MenuItem> items = menu.stream().filter(item -> productNames.contains(item.getTitle()))
                .collect(Collectors.toList());
        Order order = new Order(orderId, user);
        orderId++;
        assert orderId < 0: "The maximum number of orders have been exceeded.";
        orders.add(order);
        orderInformation.put(order, items);
        Integer price = items.stream().mapToInt(MenuItem::getPrice).sum();
        StringBuilder message = new StringBuilder("Order placed at " + order.getOrderDate() + " " + order.getOrderTime() + "\n");
        message.append("Client: ").append(order.getClientUsername()).append("\n");
        message.append("Products: \n");
        for(MenuItem item: items)
            message.append(item.getTitle()).append("\n");
        message.append("Total price: ").append(price);
        fileWriter.createBill(message.toString());
        setChanged();
        notifyObservers(message.toString());
        assert orderInformation.get(order) != null: "The order was not registered";
    }

    /**
     * Based on the input filter it creates a list of items that comply with the given conditions
     *
     * @param filter string representing the option of search
     * @param word the value of the search field
     * @return a list of menu items that comply with the given condition
     */
    public List<MenuItem> searchProduct(String filter, String word) {
        assert menu != null: "The menu list is empty";
        List<MenuItem> items = null;
        if(filter.equals("keyword"))
            items = menu.stream().filter(item -> item.getTitle().contains(word)).collect(Collectors.toList());
        else if(filter.equals("rating")) {
            Double rating = Double.parseDouble(word);
            items = menu.stream().filter(item -> item.getRating() >= rating).collect(Collectors.toList());
        } else if(filter.equals("calories")) {
            Integer value = Integer.parseInt(word);
            items = menu.stream().filter(item -> item.getCalories().equals(value)).collect(Collectors.toList());
        } else if(filter.equals("proteins")) {
            Integer value = Integer.parseInt(word);
            items = menu.stream().filter(item -> item.getProteins().equals(value)).collect(Collectors.toList());
        } else if(filter.equals("fats")) {
            Integer value = Integer.parseInt(word);
            items = menu.stream().filter(item -> item.getFats().equals(value)).collect(Collectors.toList());
        } else if(filter.equals("sodium")) {
            Integer value = Integer.parseInt(word);
            items = menu.stream().filter(item -> item.getSodium().equals(value)).collect(Collectors.toList());
        } else if(filter.equals("price")) {
            Integer value = Integer.parseInt(word);
            items = menu.stream().filter(item -> item.getPrice().equals(value)).collect(Collectors.toList());
        }
        assert items != null: "The generated search list is null";
        return items;
    }


    /**
     * Uploads into menu list all the BaseProducts that can be read from the products.csv file.
     */
    public void uploadMenu() {
        List<MenuItem> baseProducts = new ArrayList<>();
        try {
            File inputFile = new File("products.csv");

            assert inputFile.exists(): "The products.csv file does not exist.";

            InputStream inputStream = new FileInputStream(inputFile);
            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));

            baseProducts = reader.lines().skip(1).map(line -> {

                List<String> fields = Arrays.asList(line.split(","));
                MenuItem menuItem = new BaseProduct();

                ((BaseProduct) menuItem).setTitle(fields.get(0));
                ((BaseProduct) menuItem).setRating(Double.parseDouble(fields.get(1)));
                ((BaseProduct) menuItem).setCalories(Integer.parseInt(fields.get(2)));
                ((BaseProduct) menuItem).setProteins(Integer.parseInt(fields.get(3)));
                ((BaseProduct) menuItem).setFats(Integer.parseInt(fields.get(4)));
                ((BaseProduct) menuItem).setSodium(Integer.parseInt(fields.get(5)));
                ((BaseProduct) menuItem).setPrice(Integer.parseInt(fields.get(6)));

                return menuItem;
            }).distinct().collect(Collectors.toList());
            reader.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        Map<String, MenuItem> map = new HashMap<>();
        baseProducts.forEach(item -> map.put(item.getTitle(), item));
        map.keySet().forEach(item -> menu.add(map.get(item)));
        serializator.serializeMenuItems(menu);

        assert !menu.isEmpty(): "The menu is was not imported from csv file";
    }

    /**
     * Deletes from the menu list the entry which matches the given title
     * @param name string representing the title of the product
     */
    public void deleteProduct(String name) {

        assert menu.stream().map(MenuItem::getTitle).anyMatch(name::equals): "The provided name is not in the menu list";

        menu.removeIf(item -> item.getTitle().equals(name));
        setChanged();
        notifyObservers(null);

        assert menu.stream().map(MenuItem::getTitle).noneMatch(name::equals): "The provided name was not removed from menu list";
    }

    /**
     * After converting the input parameters to their respective types in the BaseProduct class, it creates and adds
     * a new base product to the menu list
     *
     * @param name title of the given product as string
     * @param rating of the given product as string
     * @param calories of the given product as string
     * @param proteins of the given product as string
     * @param fats of the given product as string
     * @param sodium of the given product as string
     * @param price of the given product as string
     */
    public void addBaseProduct(String name, String rating, String calories, String proteins, String fats, String sodium,
                               String price) {
        assert menu.stream().map(MenuItem::getTitle).noneMatch(name::equals): "The provided name already exists in the menu";
        MenuItem item = new BaseProduct(name, Double.parseDouble(rating), Integer.parseInt(calories),
                Integer.parseInt(proteins), Integer.parseInt(fats), Integer.parseInt(sodium), Integer.parseInt(price));

        menu.add(item);
        assert menu.stream().map(MenuItem::getTitle).anyMatch(name::equals) : "The provided name was not added in the menu.";
    }

    /**
     * Creates the list of the composite product by parsing the given list of titles and adding them to the composite's
     * product list
     * @param name string representing the given product's title
     * @param titlesString the new list of titles of products to be added in the composite product
     */
    public void addCompositeProduct(String name, String titlesString) {
        assert menu.stream().map(MenuItem::getTitle).noneMatch(name::equals): "The provided name already exists in the menu";
        List<String> titles = Arrays.asList(titlesString.split(","));
        List<MenuItem> compositions = menu.stream()
                .filter(item -> titles.contains(item.getTitle()))
                .collect(Collectors.toList());

        MenuItem item = new CompositeProduct(name, compositions);
        menu.add(item);
        assert menu.stream().map(MenuItem::getTitle).anyMatch(name::equals) : "The provided name was not added in the menu.";
    }

    /**
     * Updates the given base product that matches the given title and updates all its entries to match the given ones
     * @param name title of the given product as string
     * @param rating of the given product as string
     * @param calories of the given product as string
     * @param proteins of the given product as string
     * @param fats of the given product as string
     * @param sodium of the given product as string
     * @param price of the given product as string
     */
    public void updateBaseProduct(String name, String rating, String calories, String proteins, String fats, String sodium,
                                  String price) {
        assert menu.stream().map(MenuItem::getTitle).anyMatch(name::equals) : "The provided name was not found in the menu.";
        MenuItem item = new BaseProduct(name, Double.parseDouble(rating), Integer.parseInt(calories),
                Integer.parseInt(proteins), Integer.parseInt(fats), Integer.parseInt(sodium), Integer.parseInt(price));
        menu.removeIf(i -> i.getTitle().equals(name));
        menu.add(item);
        assert menu.contains(item): "The item was not updated!";
    }

    /**
     * Rebuilds the list of the composite product by parsing the given list of titles and adding them to the composite's
     * product list
     * @param title string representing the given product's title
     * @param titlesString the new list of titles of products to be added in the composite product
     */
    public void updateCompositeProduct(String title, String titlesString) {
        assert menu.stream().map(MenuItem::getTitle).anyMatch(title::equals) : "The provided name was not found in the menu.";
        List<String> titles = Arrays.asList(titlesString.split(","));
        List<MenuItem> compositions = menu.stream()
                .filter(item -> titles.contains(item.getTitle()))
                .collect(Collectors.toList());
        MenuItem item = menu.stream().filter(i -> i.getTitle().equals(title)).findAny().get();
        ((CompositeProduct) item).setBaseProducts(compositions);
        assert ((CompositeProduct) item).getBaseProducts().equals(compositions): "The composite item was not updated";
    }

    /**
     * Builds a string containing the resulted report by parsing the parameters field based on the option field and calling
     * appropriate method.
     * @param option the selected type of report to be generated (as string)
     * @param parameters the given parameters of the report generation as string
     * @return a string containing the resulted report
     */
    public String generateReport(String option, String parameters) {
        assert !parameters.isBlank(): "There was no parameter provided to generate the reports";
        String string = null;
        switch (option) {
            case "time interval":
                String[] interval = parameters.split(" ");
                string = generateTimeInterval(Integer.parseInt(interval[0]), Integer.parseInt(interval[1]));
                break;
            case "products times":
                string = generateProductsByTimes(Integer.parseInt(parameters));
                break;
            case "clients":
                String[] params = parameters.split(" ");
                string = generateClientsReport(Integer.parseInt(params[0]), Integer.parseInt(params[1]));
                break;
            case "products day":
                string = generateProductsByDay(parameters);
                break;
            default:
                string =  "";
                break;
        }
        assert string != null: "The result string was not constructed properly";
        return string;
    }

    /**
     * Builds a string containing all the orders that were made in any day between two given hours
     * @param low The lower bound as an hours (integer) of the time interval
     * @param high The upper bound as an hours (integer) of the time interval
     * @return the generated report as string
     */
    public String generateTimeInterval(Integer low, Integer high) {
        StringBuilder report = new StringBuilder();
        LocalTime lowTime = LocalTime.of(low, 0, 0);
        LocalTime highTime = LocalTime.of(high, 0, 0);
        List<Order> valid = orders.stream().filter(
                        order -> order.getOrderTime().isAfter(lowTime) && order.getOrderTime().isBefore(highTime))
                .collect(Collectors.toList());
        for(Order order: valid) {
            report.append(order);
            for(MenuItem item: orderInformation.get(order)) {
                report.append(item.getTitle()).append(" -- ");
            }
            report.append("\n\n");
        }
        return report.toString();
    }

    /**
     * Builds a string which will contain a list of titles of products that have been ordered more than "times" so far
     * @param times integer representing the amount of orders an product should pe into
     * @return the generated report string
     */
    public String generateProductsByTimes(Integer times) {
        Map<String, Integer> map = new HashMap<>();
        orderInformation.values().forEach(list -> list.forEach(item ->  {
            if(map.containsKey(item.getTitle()))
                map.put(item.getTitle(), map.get(item.getTitle()) + 1);
            else map.put(item.getTitle(), 1);
        }));
        StringBuilder stringBuilder = new StringBuilder();
        map.forEach((key, value) -> {
            if (value >= times)
                stringBuilder.append(key).append("\n");
        });
        return stringBuilder.toString();
    }

    /**
     * Builds a string that contains all the clients that have ordered more that "times" times and with a price greater
     * than "amount"
     * @param times integer representing the number of times a client needs to have been ordered to be selected
     * @param amount the minimum price of the order such that it should be taken into consideration
     * @return the generated report string
     */
    public String generateClientsReport(Integer times, Integer amount) {
        Map<String, Integer> map = new HashMap<>();
        orders.forEach(order -> {
            if(orderInformation.get(order).stream().mapToInt(MenuItem::getPrice).sum() > amount) {
                if(map.containsKey(order.getClientUsername()))
                    map.put(order.getClientUsername(), map.get(order.getClientUsername()) + 1);
                else map.put(order.getClientUsername(), 1);
            }
        });
        StringBuilder stringBuilder = new StringBuilder();
        map.forEach((key, value) -> {
            if (value >= times)
                stringBuilder.append(key).append("\n");
        });
        return stringBuilder.toString();
    }

    /**
     * Build a string that contains all the products ordered in a specific day and the number of times they have been
     * ordered
     * @param dateString the desired date as string (format: d-MM-yyyy)
     * @return the generated report string
     */
    public String generateProductsByDay(String dateString) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d-MM-yyyy");
        LocalDate date = LocalDate.parse(dateString, formatter);
        Map<String, Integer> map = new HashMap<>();
        orderInformation.entrySet().stream().filter(entry -> entry.getKey().getOrderDate().isEqual(date))
                .forEach(entry -> entry.getValue().forEach(item -> {
                    if(map.containsKey(item.getTitle()))
                        map.put(item.getTitle(), map.get(item.getTitle()) + 1);
                    else map.put(item.getTitle(), 1);
                }));
        StringBuilder stringBuilder = new StringBuilder();
        map.forEach((key, value) -> {
            stringBuilder.append(key).append(" --- ").append(value).append("\n");
        });
        return stringBuilder.toString();
    }

    /**
     * Serializes all the important objects of this application's class
     */
    public void serializeObjects() {
        fileWriter.writeOrderId(orderId);
        serializator.serializeMenuItems(menu);
        serializator.serializeOrders(orders);
        serializator.serializeOrderInformation(orderInformation);
    }

    public List<MenuItem> getMenu() {
        return menu;
    }
}
