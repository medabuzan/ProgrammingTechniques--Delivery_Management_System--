package bussiness;

import java.io.Serializable;

/**
 * Class that represents the model of this application's user accounts
 */
public class Account implements Serializable {

    private String username;
    private String password;
    private String rank;

    /**
     * Constructor of Account
     * @param username string name of the new account
     * @param password password string of the new account
     * @param rank the permissions of the new account (administrator, client, employee)
     */
    public Account(String username, String password, String rank) {
        this.username = username;
        this.password = password;
        this.rank = rank;
    }

    /**
     * Overrides the default toString method in object in order to display properly its attributes
     * @return a string representing the state of this object
     */
    @Override
    public String toString() {
        return this.username + " " + this.password + " " + this.rank;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public String getRank() {
        return rank;
    }

    public void setRank(String rank) {
        this.rank = rank;
    }
}
