package bussiness;

import java.util.ArrayList;
import java.util.List;

import data.Serializator;

/**
 * Class responsible with handling the accounts created for using this application
 */
public class AuthenticationService {

    private Serializator serializator;

    private List<Account> accounts;

    public AuthenticationService() {

        this.serializator = new Serializator();
        deserializeAccounts();
    }

    /**
     * Uses the serializator to load into this object all the account from the file accounts.ser
     */
    public void deserializeAccounts() {
        this.accounts = serializator.deserializeAccounts();
    }

    /**
     * Uses the serializator to unload from this object all the account into the file accounts.ser
     */
    public void serializeAccounts() {
        serializator.serializeAccounts(accounts);
    }

    /**
     * This method creates a new Account object with the specified parameters and adds it to the list of Accounts
     * @param user string containing the username of the account
     * @param password string containing the password of the account
     * @param rank string containing the type of the account (administrator, client, employee)
     */
    public void createAccount(String user, String password, String rank) {
        Account account = new Account(user, password, rank);

        if(accounts == null) {
            accounts = new ArrayList<>();
        }
        accounts.add(account);
    }

    /**
     * Checks if the details of an account specified through the given parameters belong
     * to an existing account inside the account list
     *
     * @param user string containing the username of the account
     * @param password string containing the password of the account
     * @param rank string containing the type of the account (administrator, client, employee)
     * @return true if the provided details belong to an existring account, otherwise false
     */
    public boolean isAccount(String user, String password, String rank) {

        if(accounts == null)
            return false;

        for(Account account: accounts) {
            if(account.getUsername().equals(user) && account.getPassword().equals(password) &&
                    account.getRank().equals(rank))
                return true;
        }

        return false;
    }

    public List<Account> getAccounts() {
        return accounts;
    }

    public void setAccounts(List<Account> accounts) {
        this.accounts = accounts;
    }
}
