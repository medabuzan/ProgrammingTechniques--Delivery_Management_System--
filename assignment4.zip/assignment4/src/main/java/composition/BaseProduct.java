package composition;

import java.io.Serializable;

/**
 * Class representing the model of an base product object abstraction
 */
public class BaseProduct extends MenuItem implements Serializable {

    private String title;
    private Double rating;
    private Integer calories;
    private Integer proteins;
    private Integer fats;
    private Integer sodium;
    private Integer price;

    public BaseProduct() {}

    /**
     * Creates a new BaseProduct and initializes its attributes with the provided values
     * @param title title of the given product as string
     * @param rating of the given product as string
     * @param calories of the given product as string
     * @param proteins of the given product as string
     * @param fats of the given product as string
     * @param sodium of the given product as string
     * @param price of the given product as string
     */
    public BaseProduct(String title, Double rating, Integer calories, Integer proteins, Integer fats, Integer sodium,
                       Integer price) {
        this.title = title;
        this.rating = rating;
        this.calories = calories;
        this.proteins = proteins;
        this.price = price;
        this.fats = fats;
        this.sodium = sodium;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Double getRating() {
        return rating;
    }

    public void setRating(Double rating) {
        this.rating = rating;
    }

    public Integer getCalories() {
        return calories;
    }

    public void setCalories(Integer calories) {
        this.calories = calories;
    }

    public Integer getProteins() {
        return proteins;
    }

    public void setProteins(Integer proteins) {
        this.proteins = proteins;
    }

    public Integer getFats() {
        return fats;
    }

    public void setFats(Integer fats) {
        this.fats = fats;
    }

    public Integer getSodium() {
        return sodium;
    }

    public void setSodium(Integer sodium) {
        this.sodium = sodium;
    }

    public Integer getPrice() {
        return price;
    }

    public void setPrice(Integer price) {
        this.price = price;
    }
}
