package composition;

import java.io.Serializable;
import java.util.List;

/**
 * Class representing the model of an composite product object abstraction
 */
public class CompositeProduct extends MenuItem implements Serializable {

    private String title;
    private List<MenuItem> baseProducts;

    /**
     * Create a new composite product from the given parameters
     * @param title name of the composite product
     * @param items Menu Items to be added in this composite product's list
     */
    public CompositeProduct(String title, List<MenuItem> items) {
        baseProducts = items;
        this.title = title;
    }

    /**
     * Adds an object to the list of composite products
     * @param item MenuItem object
     */
    public void add(MenuItem item) {
        baseProducts.add(item);
    }

    public void setBaseProducts(List<MenuItem> items) {
        baseProducts = items;
    }
    public List<MenuItem> getBaseProducts() {
        return baseProducts;
    }

    /**
     * Computes the price of this composite product by adding all the prices in the list of compositions
     * @return integer representing the price of this product
     */
    public Integer getPrice() {
        return baseProducts.stream().mapToInt(MenuItem::getPrice).sum();
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * Computes the average of all the composite's ratings
     * @return the rating of this composite product as double
     */
    public Double getRating() {
        return baseProducts.stream().mapToDouble(MenuItem::getRating).average().getAsDouble();
    }

    /**
     * Computes the sum of all calories in the list of composites
     * @return the calories of this composite product as integer
     */
    public Integer getCalories() {
        return baseProducts.stream().mapToInt(MenuItem::getCalories).sum();
    }

    /**
     * Computes the sum of all proteins in the list of composites
     * @return the proteins of this composite product as integer
     */
    public Integer getProteins() {
        return baseProducts.stream().mapToInt(MenuItem::getProteins).sum();
    }

    /**
     * Computes the sum of all fats in the list of composites
     * @return the fats of this composite product as integer
     */
    public Integer getFats() {
        return baseProducts.stream().mapToInt(MenuItem::getFats).sum();
    }

    /**
     * Computes the sum of all sodium in the list of composites
     * @return the sodium of this composite product as integer
     */
    public Integer getSodium() {
        return baseProducts.stream().mapToInt(MenuItem::getSodium).sum();
    }
}
