package composition;

/**
 * The class which implements an item in the menu
 */
public class MenuItem {

    public String getTitle() {
        return null;
    }

    public Double getRating() { return 0.;}

    public Integer getCalories() {
        return 0;
    }

    public Integer getProteins() {
        return 0;
    }

    public Integer getFats() {
        return 0;
    }

    public Integer getSodium() {
        return 0;
    }

    public Integer getPrice() {
        return 0;
    }
}
